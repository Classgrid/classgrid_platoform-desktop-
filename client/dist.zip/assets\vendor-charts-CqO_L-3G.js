import"./vendor-react-CNZ9KNTL.js";var i="Invariant failed";function e(r,a){if(!r)throw new Error(i)}export{e as i};
